"Uuuugggg" -The sound I make when I need to format a new README.md file

# BASICRPG
Author: Unlisted_dev

Welcome to BasicRPG!
This is a python module for making RPG games, clean and easy.

## NOTE: DOCUMENTATION IS NOT HERE, PROPER DOCUMENTATION COMING SOON

### Begginer friendly.
My intent for this project was to make it as begginer friendly as possible. While there are some fairly advanced things in here, I try to explain it as much as I can. I encourage you to experiment with the small number of premade assets included in the starter_pack, and then go make your own! Every folder in this project has a README.md that will contain some useful pieces of information. If anything is intimidating to you right now, go through the project and read the READMEs.

### Current list of objects
Im not gonna tell you what they do though, figure that out  
race  
profession  
character  
food  
weapon  

### Why
Wanna hear a backstory? Sure you do.
I started learning to code in grade 1 or 2 with scratch. I loved making games and learning new things. Every game I made, I added a new mechanic that used concepts I didnt know of before, and this was how I learnt. Honestly, it was the best way to learn in my opinion (take some notes [INSERT NAME OF EDUCATIONAL INSTITUTION]). In grade 5, I wanted something new, scratch was making me feel like a boring programmer, so I found python. I took some online class in python, codeAcademy I think, which was great for learning the basics, but soon it felt overcomplicated, too much boring math that I didn't understand. YouTube was my saviour, I learned how to take a user input and that was all I needed. For the next few years I made choose your own adventure games, but my programming skills improved barely at all. I created little projects from time to time, but often got confused or lost. After a break from coding, almost too long, something rekindled my interest, and I set out to make a new choose your own adventure game that would be organised this time. I didn't want what happened to me the last million times to happen again, and it didn't. I succesfully created my first COMPLETE choose your own adventure game in python, and it only took 3 years... What really started my leap in programming skill was when I discoverd linux developer mode on my school laptop, and downloaded my favourite code editor: VScode. Every chance I got, whenever I was bored in class, I stopped playing brain rotting games and started coding. What else is school for? Ever since then, I have learned more and more. I consumed nerd knowledge like a sponge, put live operating systems on old USB drives, repaired thrown away computers with salvaged parts, programmed everything I was interested in in that moment from neural networks to fibinachi sequence generators, created a GitHub account to share my creations with the world. Some of you may say "Wow so incredible", other may say "Yeah, we've all been there, done that", either way, I don't care what you think. So then why did I publish my villian arc? Because maybe you, yes you, are starting your programming journey, and I want you to know how much there is to learn, and how much is out there. The world of technology has so much to offer, and it's not only for losers who do nothing but pre-cal homework and try-harding the shit out of school, it can be for you to, just like it was for me. In this project, I have included tones of comments in an attempt to explain as much as I can. I hope you will learn something.

### Ummmm
After writing all that, I forgot what a README is suposed to have, so i'll put what's on my mind here
-I really need some neat ascii art in some part of this project, like that would be absolutly sick
-Better do real README stuff, tommorow tho, it's too late. 
-Oh ya, find bugs, DM me
-also like and subscribe, or whatever GitHub has

### Contact me
Literaly anything, don't be weird. DMs always open: Unlisted_dev (discord)


Ps: You don't have to be a gay furry either, although they do have a plus 15 on all programming related rolls